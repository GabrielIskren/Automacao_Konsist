import os
import re
import json
import logging
from datetime import datetime, timedelta
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from pathlib import Path

# =================== CONFIG ===================

dominio = os.environ.get('USERDOMAIN')

TELEGRAM_TOKEN   = os.getenv("TELEGRAM_TOKEN", "8255979889:AAGocw4T3K0tdV4EtPHNcqSB20Z5qz02UrE").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "8099774920").strip()
MANTER_ARQUIVOS  = 7
PADRAO_DATA      = r"\d{4}-\d{2}-\d{2}"
nome_cliente = dominio
PADRAO_CLIENTE   = r"\d{4}-\d{2}-\d{2}-([a-zA-Z0-9_\-]+)---backup\.backup"
SYSTEM_FOLDERS_TO_SKIP = ['\\program files', '\\programdata', 'backup_antigo']
# ==============================================

# Configuração do logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('backup_automation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def send_telegram_message(texto: str):
    if not TELEGRAM_TOKEN:
        logger.warning("TOKEN do Telegram não configurado. Mensagem não enviada.")
        return
    if not TELEGRAM_CHAT_ID:
        logger.warning("CHAT_ID do Telegram não configurado. Mensagem não enviada.")
        return

    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        data = urlencode({"chat_id": TELEGRAM_CHAT_ID, "text": texto}).encode()
        req = Request(url, data=data)
        with urlopen(req) as resp:
            body = resp.read().decode("utf-8")
            try:
                j = json.loads(body)
            except json.JSONDecodeError:
                j = {"raw": body}

            if resp.status == 200 and j.get("ok"):
                logger.info("✅ Alerta enviado via Telegram.")
            else:
                logger.error(f"⚠ Falha ao enviar Telegram (HTTP {resp.status}): {j}")
    except Exception as e:
        logger.error(f"❌ Erro ao enviar Telegram: {e}")

def listar_discos():
    discos = []
    for letra in range(65, 91):
        drive = f"{chr(letra)}:\\\\"
        if Path(drive).exists():
            discos.append(drive)
    logger.info(f"Discos encontrados: {discos}")
    return discos

def buscar_pastas_konsist():
    pastas_encontradas = []
    for disco in listar_discos():
        logger.info(f"🔍 Varredura no disco: {disco}")
        try:
            for root, dirs, files in os.walk(disco):
                rl = root.lower()
                if any(skip in rl for skip in SYSTEM_FOLDERS_TO_SKIP):
                    continue
                if "konsist" in rl:
                    pastas_encontradas.append(root)
                    logger.info(f"📂 Pasta encontrada: {root}")
        except (PermissionError, OSError) as e:
            logger.warning(f"Erro ao acessar {disco}: {e}")
            continue

    if not pastas_encontradas:
        logger.warning("Nenhuma pasta contendo 'konsist' foi encontrada.")
    else:
        logger.info(f"✅ Total de pastas encontradas: {len(pastas_encontradas)}")
    return pastas_encontradas

def analisar_e_limpar_backups(pastas, manter=MANTER_ARQUIVOS):
    ontem = datetime.now().date() - timedelta(days=1)
    faltas_por_disco = {}

    for pasta in pastas:
        try:
            backups = []
            pasta_path = Path(pasta)

            if not pasta_path.exists():
                logger.warning(f"Pasta não existe: {pasta}")
                continue

            for arquivo in pasta_path.iterdir():
                if arquivo.is_file() and arquivo.suffix.lower() == ".backup":
                    m = re.search(PADRAO_DATA, arquivo.name)
                    if m:
                        try:
                            data_arquivo = datetime.strptime(m.group(), "%Y-%m-%d").date()
                            backups.append((arquivo.name, data_arquivo))
                        except ValueError:
                            logger.warning(f"Data inválida no arquivo: {arquivo.name}")

            logger.info(f"\n📂 Pasta: {pasta}")
            if not backups:
                logger.info("Nenhum arquivo de backup encontrado nesta pasta.")
                continue

            backups.sort(key=lambda x: x[1], reverse=True)
            datas = [d for _, d in backups]

            # Nome do cliente
#            nome_cliente = "Desconhecido"
#            if backups:
#                m_cliente = re.search(PADRAO_CLIENTE, backups[0][0])
#                if m_cliente:
#                    nome_cliente = m_cliente.group(1)

            # Verificação backup de ontem
            if ontem in datas:
                logger.info(f"✅ Backup de ontem ({ontem}) está presente.")
            else:
                logger.warning(f"⚠ ATENÇÃO: Não existe backup de ontem ({ontem})!")
                drive = pasta_path.parts[0] if pasta_path.parts else "DESCONHECIDO"
                faltas_por_disco.setdefault(drive, []).append(f"Diretório do backup:\n{pasta}")

            # Verificação tamanho do backup mais recente
            backup_mais_recente_nome = backups[0][0]
            backup_mais_recente_path = pasta_path / backup_mais_recente_nome
            if backup_mais_recente_path.stat().st_size == 0:
                alerta = (f"⚠ O backup do(a) {nome_cliente} está vazio!\n\n"
                          f"• Diretório:\n {pasta}\n• Arquivo:\n {backup_mais_recente_nome}")
                logger.warning(alerta)
                send_telegram_message(alerta)

            # Mostrar e manter apenas os N mais recentes
            logger.info(f"Total de arquivos de backup: {len(backups)}")
            logger.info(f"🟢 {manter} mais recentes:")
            for nome, data in backups[:manter]:
                logger.info(f"   - {nome} (Data: {data})")

            # Apagar antigos
            antigos = backups[manter:]
            if antigos:
                logger.info(f"\n🗑 Apagando {len(antigos)} backups antigos...")
                for nome, data in antigos:
                    caminho = pasta_path / nome
                    try:
                        caminho.unlink()
                        logger.info(f"   ✔ Apagado: {nome} (Data: {data})")
                    except OSError as e:
                        logger.error(f"   ❌ Erro ao apagar {nome}: {e}")
            else:
                logger.info("Nenhum backup antigo para apagar.")

        except Exception as e:
            logger.error(f"Erro ao processar pasta {pasta}: {e}")

    if faltas_por_disco:
        linhas = [f"⚠ Backup do Konsist do(a) {nome_cliente} está em estado de erro:"]
        for disco, pastas_faltando in faltas_por_disco.items():
            linhas.append(f"\n")
            for p in pastas_faltando:
                linhas.append(f"• {p}")
        send_telegram_message("\n".join(linhas))
    else:
        logger.info("✅ Todos os discos/pastas verificados possuem backup de ontem.")

if __name__ == "__main__":
    logger.info("Iniciando automação de limpeza de backups...")
    try:
        pastas = buscar_pastas_konsist()
        if pastas:
            analisar_e_limpar_backups(pastas)
        else:
            logger.warning("Nenhuma pasta encontrada para processar.")
    except Exception as e:
        logger.error(f"Erro crítico na execução: {e}")
        send_telegram_message(f"❌ Erro crítico na automação de backup: {e}")
    finally:
        logger.info("Automação finalizada.")
